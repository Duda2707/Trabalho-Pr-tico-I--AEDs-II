
/*
Seu nome
Seu RA
Seu curso
Seu email
Data de entrega
*/

// Referência: [Aula de Algoritmos e Estruturas de Dados I - Ordenação](https://ww2.inf.ufg.br/~hebert/disc/aed1/AED1_04_ordenacao1.pdf)
// Referência: [Algoritmos de ordenação: análise e comparação](https://www.devmedia.com.br/algoritmos-de-ordenacao-analise-e-comparacao/28261)
// Referência: [Algoritmos de ordenação](https://www.ime.usp.br/~pf/algoritmos/aulas/ordena.html)

#include <iostream> // biblioteca para usar cout, cin, endl...
#include <vector>   // biblioteca para usar vetores
#include <fstream>  // biblioteca para usar arquivos
#include <time.h>   // biblioteca para usar a função de tempo
#include <map>      // biblioteca para usar map
#include <iomanip>  // biblioteca para usar setw()
#include <string>   // biblioteca para usar string
// #include <algorithm> // biblioteca para usar sort()

using namespace std;

// ------------------------- MENU ------------------------- //

void MenuPrincipal()
{ // menu principal

    cout << " Escolha um dos algoritmos de ordenacao " << endl
         << endl;
    cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << endl;
    cout << setw(45) << "1 - Bubble Sort" << endl
         << endl;
    cout << setw(46) << "2 - Insertion Sort" << endl
         << endl;
    cout << setw(46) << "3 - Selection Sort" << endl
         << endl;
    cout << setw(46) << "4 - Quick Sort" << endl
         << endl;
    cout << setw(46) << "5 - Merge Sort" << endl
         << endl;
    cout << setw(46) << "6 - Shell Sort" << endl
         << endl;
    cout << setw(43) << "7 - Sair" << endl
         << endl;
    cout << "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-" << endl;
}

void MenuPrincipalDeMetodos()
{ // menu principal de metodos

    cout << "Escolha uma das instancias: " << endl << endl;
    cout << "  INSTANCIAS DE 1000" << endl;
    cout << "1 - Lista ordenada de 1000\n";
    cout << "2 - Lista odenada de 1000\n";
    cout << "3 - Lista aleatoria de 1000\n";
    cout << "4 - Lista inversamente ordenada de 1000\n";
    cout << "  INSTANCIAS DE 10000\n";
    cout << "5 - Lista ordenada de 10000\n";
    cout << "6 - Lista odenada de 10000\n";
    cout << "7 - Lista aleatoria de 10000\n";
    cout << "8 - Lista inversamente ordenada de 1000\n";
    cout << "  INSTANCIAS DE 100000\n";
    cout << "9 - Lista ordenada de 100000\n";
    cout << "10 - Lista odenada de 100000\n";
    cout << "11 - Lista aleatoria de 100000\n";
    cout << "12 - Lista inversamente ordenada de 10000\n";
    cout << "  INSTANCIAS DE 1000000\n";
    cout << "13 - Lista ordenada de 1000000\n";
    cout << "14 - Lista odenada de 1000000\n";
    cout << "15 - Lista aleatoria de 1000000\n";
    cout << "16 - Lista inversamente ordenada de 1000000\n";
    cout << "  INSTANCIAS DE DICIONARIO de 29855\n";
    cout << "17 - Dicionario ordenado 29855\n";
    cout << "18 - Dicionario aleatorio de 29855\n";
    cout << "19 - Dicionario inversamente ordenado - 29855\n";
    cout << "  INSTANCIAS DE DICIONARIO de 261791\n";
    cout << "20 - Dicionario ordenado 261791\n";
    cout << "21 - Dicionario aleatorio de 261791\n";
    cout << "22 - Dicionario inversamente ordenado - 261791\n";
    cout << "23 - Sair\n";
}

vector<int> NumeroParaVetor;    // esse vetor vai ser usado para ler os numeros
vector<string> VetorParaString; // esse vetor vai ser usado para ler o dicionario

void LerArquivo(int op, vector<int> &NumeroParaVetor, vector<string> &VetorParaString)
{                             // ler arquivo
    map<int, string> file_map{// map para ler os arquivos

    {1, "../ListaOrdenada-1000.txt"},
    {2, "../ListaQuaseOrdenada-1000.txt"},
    {3, "../ListaAleatoria-1000.txt"},
    {4, "../ListaInversamenteOrdenada-1000.txt"},
    {5, "../ListaOrdenada-10000.txt"},
    {6, "../ListaQuaseOrdenada-10000.txt"},
    {7, "../ListaAleatoria-10000"},
    {8, "../ListaInversamenteOrdenada-10000.txt"},
    {9, "../ListaOrdenada-100000.txt"},
    {10, "../ListaQuaseOrdenada-100000.txt"},
    {11, "../ListaAleatoria-100000.txt"},
    {12, "../ListaInversamenteOrdenada-100000.txt"},
    {13, "../ListaOrdenada-1000000.txt"},
    {14, "../ListaQuaseOrdenada-1000000.txt"},
    {15, "../ListaAleatoria-1000000.txt"},
    {16, "../ListaInversamenteOrdenada-1000000.txt"},
    {17, "../DicionarioOrdenado-29855.txt"},
    {18, "../DicionarioAleatorio-29855.txt"},
    {19, "../DicionarioInversamenteOrdenado-29855.txt"},
    {20, "../DicionarioOrdenado-261791.txt"},
    {21, "../DicionarioAleatorio-261791.txt"},
    {22, "../DicionarioInversamenteOrdenado-261791.txt"}};

    ifstream file(file_map[op]); // abre o arquivo
    string line;                 // variavel para ler as linhas do arquivo

    if (file.is_open())
    { // se o arquivo estiver aberto
        while (getline(file, line))
        {
            if (op < 17)
            {                                          // se for menor que 17, vai ler os numeros
                NumeroParaVetor.push_back(stoi(line)); // adiciona o numero no vetor
            }
            else
            {                                    // se for maior que 17, vai ler as strings
                VetorParaString.push_back(line); // adiciona a string no vetor
            }
        }
        file.close();
    }
    else // se o arquivo nao abrir
    {
        cout << "Algo deu errado ao abir o arquivo!!!" << endl;
    }
}

// Menus
void MenuPrincipal();          // menu principal
void MenuPrincipalDeMetodos(); // menu principal de metodos
void BackMenuPrincipal();      // voltar para o menu principal

// Ordenacao: BubbleSort, InsertionSort, SelectionSort, QuickSort, MergeSort, ShellSort

void BubbleSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap);               // bubble sort
void BubbleSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap); // bubble sort para string

void InsertionSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap);               // insertion sort
void InsertionSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap); // insertion sort para string

void SelectionSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap);               // selection sort
void SelectionSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap); // selection sort para string

void QuickSort(vector<int> &NumeroParaVetor, int esq, int dir, unsigned long long *comparar, unsigned long long *swap);               // quick sort
void QuickSort_for_String(vector<string> &VetorParaString, int esq, int dir, unsigned long long *comparar, unsigned long long *swap); // quick sort para string

void Merge(vector<int> &NumeroParaVetor, int esq, int dir, unsigned long long *comparar, unsigned long long *swap);                   // merge sort
void MergeSort_for_String(vector<string> &VetorParaString, int esq, int dir, unsigned long long *comparar, unsigned long long *swap); // merge sort para string

void ShellSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap);               // shell sort
void ShellSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap); // shell sort para string

// Manipulacao
void LerArquivo(int op, vector<int> &NumeroParaVetor, vector<string> &VetorParaString);                                // ler arquivo
void OrdenarArquivo(vector<int> &NumeroParaVetor, vector<string> &VetorParaString, int metodo, int instancia);         // ordenar arquivo
void OrdenarArquivoDaString(vector<string> &VetorParaString, vector<int> &NumeroParaVetor, int metodo, int instancia); // ordenar arquivo da string
void ImprimirAString(vector<string> &VetorParaString);                                                                 // imprime o vetor de string

/* // Segundo menu principal opcional
void MenuPrincipal()
{
    int opcao, instancia, metodo;
    vector<int> NumeroParaVetor;
    vector<string> VetorParaString;

    cout << "Escolha uma opcao: " << endl;
    cout << "1 - Ordenar arquivo de inteiros" << endl;
    cout << "2 - Ordenar arquivo de strings" << endl;
    cout << "3 - Sair" << endl;
    cin >> opcao;

    switch (opcao)
    {
    case 1:
        system("cls");
        cout << "Escolha uma opcao: " << endl;
        cout << "1 - Bubble Sort" << endl;
        cout << "2 - Insertion Sort" << endl;
        cout << "3 - Selection Sort" << endl;
        cout << "4 - Quick Sort" << endl;
        cout << "5 - Merge Sort" << endl;
        cout << "6 - Shell Sort" << endl;
        cout << "7 - Voltar" << endl;
        cin >> metodo;
        if (metodo == 7)
        {
            system("cls");
            MenuPrincipal();
        }
        else
        {
            cout << "Escolha uma instancia: " << endl;
            cout << "1 - 1000" << endl;
            cout << "2 - 10000" << endl;
            cout << "3 - 100000" << endl;
            cout << "4 - 1000000" << endl;
            cout << "5 - 10000000" << endl;
            cout << "6 - Voltar" << endl;
            cin >> instancia;
            if (instancia == 6)
            {
                system("cls");
                MenuPrincipal();
            }
            else
            {
                OrdenarArquivo(NumeroParaVetor, VetorParaString, metodo, instancia);
                BackMenuPrincipal();
            }
        }
        break;
    case 2:
        system("cls");
        cout << "Escolha uma opcao: " << endl;
        cout << "1 - Bubble Sort" << endl;
        cout << "2 - Insertion Sort" << endl;
        cout << "3 - Selection Sort" << endl;
        cout << "4 - Quick Sort" << endl;
        cout << "5 - Merge Sort" << endl;
        cout << "6 - Shell Sort" << endl;
        cout << "7 - Voltar" << endl;
        cin >> metodo;
        if (metodo == 7)
        {
            system("cls");
            MenuPrincipal();
        }
        else
        {
            cout << "Escolha uma instancia: " << endl;
            cout << "1 - 1000" << endl;
            cout << "2 - 10000" << endl;
            cout << "3 - 100000" << endl;
            cout << "4 - 1000000" << endl;
            cout << "5 - 10000000" << endl;
            cout << "6 - Voltar" << endl;
            cin >> instancia;
            if (instancia == 6)
            {
                system("cls");
                MenuPrincipal();
            }
            else
            {
                OrdenarArquivoDaString(NumeroParaVetor, VetorParaString, metodo, instancia);
                BackMenuPrincipal();
            }
        }
        break;
    case 3:
        cout << "Saindo..." << endl;
        exit(0);
        break;
    default:
        cout << "Opcao invalida!!!" << endl;
        break;
    }
}
*/

int main()
{

    const int MAX_INSTANCIA = 23;     // numero de instancias
    const int MIN_NUM_INSTANCIA = 1;  // numero minimo de instancias
    const int MAX_NUM_INSTANCIA = 16; // numero maximo de instancias

    int metodo = 0;
    int instancia = 0;

    do
    {
        MenuPrincipal();
        cout << "\nEscolha o medodo de ordenacao: ";
        cin >> metodo;

        if (metodo != 7)
        {
            MenuPrincipalDeMetodos();
            cout << "Escolha a instacia: ";
            cin >> instancia;

            if (instancia == MAX_INSTANCIA)
            {
                break;
            }
        }

        if (instancia >= MIN_NUM_INSTANCIA && instancia <= MAX_NUM_INSTANCIA)
        {
            LerArquivo(instancia, NumeroParaVetor, VetorParaString);
            OrdenarArquivo(NumeroParaVetor, VetorParaString, metodo, instancia);
        }
        else if (instancia > MAX_NUM_INSTANCIA && instancia < MAX_INSTANCIA)
        {
            LerArquivo(instancia, NumeroParaVetor, VetorParaString);
            OrdenarArquivoDaString(VetorParaString, NumeroParaVetor, metodo, instancia);
        }
        else
        {
            cout << "Saindo!!!";
        }
        // sai
    } while (metodo != 7);

    return 0;
}

/*
void OrdenarArquivo(vector<int> &NumeroParaVetor, vector<string> &VetorParaString, int metodo, int instancia)
{
    unsigned long long comparar = 0;
    unsigned long long swap = 0;

    switch (metodo)
    {
    case 1:
        BubbleSort(NumeroParaVetor, &comparar, &swap);
        break;
    case 2:
        InsertionSort(NumeroParaVetor, &comparar, &swap);
        break;
    case 3:
        SelectionSort(NumeroParaVetor, &comparar, &swap);
        break;
    case 4:
        QuickSort(NumeroParaVetor, 0, NumeroParaVetor.size() - 1, &comparar, &swap);
        break;
    case 5:
        MergeSort(NumeroParaVetor, 0, NumeroParaVetor.size() - 1, &comparar, &swap);
        break;
    case 6:
        ShellSort(NumeroParaVetor, &comparar, &swap);
        break;
    default:
        cout << "Metodo invalido!!!" << endl;
        break;
    }

    ImprimirArquivo(NumeroParaVetor, VetorParaString, metodo, instancia, comparar, swap);
}
*/
// --------------------METODOS DE ORDENACAO INT-------------------- //

void BubbleSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    int auxiliar; // variável auxiliariliar para troca de elementos

    int trocou;   // variável auxiliariliar para verificar se houve troca de elementos

    // loop externo que itera o vetor NumeroParaVetor.size() - 1 vezes
    for (int i = 0; i < NumeroParaVetor.size() - 1; i++)
    {
        trocou = 0; // inicializa a variável de troca como 0
        // loop interno que itera sobre o vetor a partir da segunda posição
        // até o tamanho do vetor menos o índice i
        for (int j = 1; j < NumeroParaVetor.size() - i; j++)
        {
            // compara os elementos nas posições j e j-1
            if (NumeroParaVetor[j] < NumeroParaVetor[j - 1])
            {
                (*comparar)++;                               // incrementa o número de comparações
                auxiliar = NumeroParaVetor[j];               // armazena o valor de NumeroParaVetor[j] em auxiliar
                NumeroParaVetor[j] = NumeroParaVetor[j - 1]; // substitui NumeroParaVetor[j] por NumeroParaVetor[j-1]
                NumeroParaVetor[j - 1] = auxiliar;           // substitui NumeroParaVetor[j-1] por auxiliar
                trocou = 1;                                  // indica que houve troca no vetor
                (*swap)++;                                   // incrementa o número de trocas
            }
            else
            {
                (*comparar)++; // incrementa o número de comparações
            }
        }
        // verifica se houve alguma troca no vetor
        if (trocou == 0)
        {
            break; // se não houve, interrompe o loop externo
        }
    }
}

void InsertionSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    int auxiliar;

    for (int i = 1; i < NumeroParaVetor.size(); i++)
    {
        auxiliar = NumeroParaVetor[i]; // guarda o elemento atual
        int j = i;
        while (j > 0 && auxiliar < NumeroParaVetor[j - 1]) // procura a posição correta do elemento atual
        {
            NumeroParaVetor[j] = NumeroParaVetor[j - 1]; // desloca os elementos maiores para a dir
            j--;
            (*comparar)++; // incrementa o número de comparações
            (*swap)++;     // incrementa o número de trocas
        }
        if (j != i) // se o elemento atual foi movido, insere-o na posição correta
        {
            NumeroParaVetor[j] = auxiliar;
            (*swap)++; // incrementa o número de trocas
        }
    }
}

void SelectionSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    int min, i, j;
    int auxiliar;

    // Loop por todo o vetor
    for (i = 0; i < NumeroParaVetor.size(); i++)
    {
        // Define o índice do elemento mínimo como o índice atual do loop externo
        min = i;

        // Loop para encontrar o índice do menor elemento restante no vetor
        for (j = i + 1; j < NumeroParaVetor.size(); j++)
        {
            // Conta uma comparação de elementos
            (*comparar)++;

            // Se o elemento atual é menor do que o elemento mínimo encontrado até agora
            if (NumeroParaVetor[j] < NumeroParaVetor[min])
            {
                // Define o índice do elemento mínimo como o índice atual
                min = j;
            }
        }

        // Troca o elemento atual com o menor elemento encontrado
        auxiliar = NumeroParaVetor[i];
        NumeroParaVetor[i] = NumeroParaVetor[min];
        NumeroParaVetor[min] = auxiliar;

        // Conta uma troca de elementos
        (*swap)++;
    }
}

void QuickSort(vector<int> &NumeroParaVetor, int esq, int dir, unsigned long long *comparar, unsigned long long *swap)
{
    int temp;
    int i = esq, j = dir;
    int pivo = NumeroParaVetor[(esq + dir) / 2]; // escolhe o pivo

    while (i <= j)
    {
        while (NumeroParaVetor[i] < pivo) // procura elementos menores que o pivo na parte esquerda
            i++;
        while (NumeroParaVetor[j] > pivo) // procura elementos maiores que o pivo na parte direita
            j--;

        (*comparar)++;
        if (i <= j) // se encontrou um par de elementos que precisam ser trocados
        {
            temp = NumeroParaVetor[i];
            NumeroParaVetor[i] = NumeroParaVetor[j];
            NumeroParaVetor[j] = temp;
            i++;
            j--;

            (*swap)++;
        }
    }

    (*comparar)++;
    if (esq < j) // ordena recursivamente a parte esquerda
        QuickSort(NumeroParaVetor, esq, j, comparar, swap);
    (*comparar)++;
    if (i < dir) // ordena recursivamente a parte direita
        QuickSort(NumeroParaVetor, i, dir, comparar, swap);
}

void Merge(vector<int> &NumeroParaVetor, int inicio, int meio, int final, unsigned long long *comparar, unsigned long long *swap)
{
    int i, j, k;
    int n1 = meio - inicio + 1;
    int n2 = final - meio;

    // Cria subvetores Temporários L e R
    int *L = new int[n1];
    int *R = new int[n2];

    // Copia os elementos do subvetor esquerdo para L[]
    for (i = 0; i < n1; i++)
    {
        L[i] = NumeroParaVetor[inicio + i];
    }
    // Copia os elementos do subvetor direito para R[]
    for (j = 0; j < n2; j++)
    {
        R[j] = NumeroParaVetor[meio + 1 + j];
    }

    i = 0;
    j = 0;
    k = inicio;

    // Intercale os subvetores em ordem crescente
    while (i < n1 && j < n2)
    {
        (*comparar)++;
        if (L[i] <= R[j])
        {
            NumeroParaVetor[k] = L[i];
            i++;
        }
        else
        {
            NumeroParaVetor[k] = R[j];
            j++;
        }
        k++;
        (*swap)++;
    }

    // Copie os elementos restantes do subvetor esquerdo
    while (i < n1)
    {
        NumeroParaVetor[k] = L[i];
        i++;
        k++;
        (*swap)++;
    }

    // Copie os elementos restantes do subvetor direito
    while (j < n2)
    {
        NumeroParaVetor[k] = R[j];
        j++;
        k++;
        (*swap)++;
    }

    // Libera a memória alocada para L e R
    delete[] L;
    delete[] R;
}

void MergeSort(vector<int> &NumeroParaVetor, int inicio, int final, unsigned long long *comparar, unsigned long long *swap)
{
    if (inicio < final)
    {
        int meio = inicio + (final - inicio) / 2;

        // Ordena o subvetor esquerdo
        MergeSort(NumeroParaVetor, inicio, meio, comparar, swap);
        // Ordena o subvetor direito
        MergeSort(NumeroParaVetor, meio + 1, final, comparar, swap);

        // Intercala os subvetores ordenados
        Merge(NumeroParaVetor, inicio, meio, final, comparar, swap);
    }
}

void ShellSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    int h , x, i, j; // o h significa o tamanho da sub-lista, 

    // Calcula o valor inicial de h
    for (h = 1; h < NumeroParaVetor.size(); h = 3 * h + 1)
        ;

    // Executa a ordenação enquanto h for maior do que 1
    while (h > 1)
    {
        // Calcula o próximo valor de h
        h = h / 3;

        // Insere os elementos na sub-lista e ordena essa sub-lista com um Insertion Sort
        for (i = h; i < NumeroParaVetor.size(); i++)
        {
            // Seleciona o elemento a ser inserido na sub-lista
            x = NumeroParaVetor[i];
            j = i;

            // Ordena a sub-lista
            while (j >= h && NumeroParaVetor[j - h] > x)
            {
                (*comparar)++;
                NumeroParaVetor[j] = NumeroParaVetor[j - h];
                j = j - h;
                (*swap)++;
            }
            NumeroParaVetor[j] = x;
            (*comparar)++;
        }
    }
}

/* Apenas para teste e estudos em estrutura de dados

void Heapify(vector<int> &NumeroParaVetor, int n, int i, unsigned long long *comparar, unsigned long long *swap)
{
    int maior = i; // Inicializa o maior como raiz
    int esq = 2 * i + 1; // esq = 2*i + 1
    int dir = 2 * i + 2; // dir = 2*i + 2

    if (esq < n && NumeroParaVetor[esq] > NumeroParaVetor[maior])
        maior = esq;

    if (dir < n && NumeroParaVetor[dir] > NumeroParaVetor[maior])
        maior = dir;

    // Se o maior não é a raiz
    if (maior != i)
    {
        swap(NumeroParaVetor[i], NumeroParaVetor[maior]);

        // Recursivamente transforma o heap afetado em um max-heap
        Heapify(NumeroParaVetor, n, maior, comparar, swap);
    }
}

void HeapSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    
    for (int i = NumeroParaVetor.size() / 2 - 1; i >= 0; i--)
        Heapify(NumeroParaVetor, NumeroParaVetor.size(), i, comparar, swap);

    for (int i = NumeroParaVetor.size() - 1; i >= 0; i--)
    {
        
        swap(NumeroParaVetor[0], NumeroParaVetor[i]);

        // chama max heapify na heap reduzida
        Heapify(NumeroParaVetor, i, 0, comparar, swap);
    }
}

void HeapSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    for (int i = VetorParaString.size() / 2 - 1; i >= 0; i--)
        Heapify_for_String(VetorParaString, VetorParaString.size(), i, comparar, swap);

    for (int i = VetorParaString.size() - 1; i >= 0; i--)
    {
        swap(VetorParaString[0], VetorParaString[i]);

        // chama max heapify na heap reduzida
        Heapify_for_String(VetorParaString, i, 0, comparar, swap);
    }
}

void RadixSort(vector<int> &NumeroParaVetor, unsigned long long *comparar, unsigned long long *swap)
{
    int maior = NumeroParaVetor[0];
    int exp = 1;
    int n = NumeroParaVetor.size();
    vector<int> b(n);

    for (int i = 1; i < n; i++)
    {
        if (NumeroParaVetor[i] > maior)
            maior = NumeroParaVetor[i];
    }

    while (maior / exp > 0)
    {
        int bucket[10] = {0};

        for (int i = 0; i < n; i++)
            bucket[(NumeroParaVetor[i] / exp) % 10]++;

        for (int i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];

        for (int i = n - 1; i >= 0; i--)
            b[--bucket[(NumeroParaVetor[i] / exp) % 10]] = NumeroParaVetor[i];

        for (int i = 0; i < n; i++)
            NumeroParaVetor[i] = b[i];

        exp *= 10;
    }
}

void RadixSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    int maior = VetorParaString[0].length();
    int exp = 1;
    int n = VetorParaString.size();
    vector<string> b(n);

    for (int i = 1; i < n; i++)
    {
        if (VetorParaString[i].length() > maior)
            maior = VetorParaString[i].length();
    }

    while (maior / exp > 0)
    {
        int bucket[10] = {0};

        for (int i = 0; i < n; i++)
            bucket[(VetorParaString[i].length() / exp) % 10]++;

        for (int i = 1; i < 10; i++)
            bucket[i] += bucket[i - 1];

        for (int i = n - 1; i >= 0; i--)
            b[--bucket[(VetorParaString[i].length() / exp) % 10]] = VetorParaString[i];

        for (int i = 0; i < n; i++)
            VetorParaString[i] = b[i];

        exp *= 10;
    }
}

*/

// --------------------METODOS DE ORDENACAO STR-------------------- //

void BubbleSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    string auxiliar;    // variável auxiliariliar para facilitar a troca de strings
    bool trocou = true; // flag para indicar se houve alguma troca no vetor

    // loop externo que itera o vetor até que nenhuma troca seja realizada
    for (int i = 0; i < VetorParaString.size() - 1 && trocou; i++)
    {
        trocou = false; // inicializa a flag como false no início de cada iteração

        // loop interno que compara e troca as strings adjacentes
        for (int j = 1; j < VetorParaString.size() - i; j++)
        {
            // compara as strings adjacentes e realiza a troca caso necessário
            if (VetorParaString[j] < VetorParaString[j - 1])
            {
                (*comparar)++; // incrementa o número de comparações
                auxiliar = VetorParaString[j];
                VetorParaString[j] = VetorParaString[j - 1];
                VetorParaString[j - 1] = auxiliar;
                trocou = true; // indica que houve uma troca no vetor
                (*swap)++;     // incrementa o número de trocas
            }
            else
            {
                (*comparar)++; // incrementa o número de comparações
            }
        }
    }
}

void InsertionSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    string auxiliar;                                 // variável auxiliariliar para fazer a troca de elementos
    for (int i = 1; i < VetorParaString.size(); i++) // itera pelos elementos do vetor a partir da segunda posição
    {
        auxiliar = VetorParaString[i]; // armazena o elemento atual em uma variável auxiliariliar
        int j = i;
        while (j > 0 && auxiliar < VetorParaString[j - 1]) // enquanto houver elementos à esq do atual e o elemento atual for menor que o elemento à esq
        {
            VetorParaString[j] = VetorParaString[j - 1]; // desloca o elemento à esquerda para a direita
            j--;                                         // decrementa a posição
            (*comparar)++;                               // incrementa o contador de comparações
            (*swap)++;                                   // incrementa o contador de trocas
        }
        if (j != i) // se a posição atual for diferente da posição original
        {
            VetorParaString[j] = auxiliar; // insere o elemento na posição correta
            (*swap)++;                     // incrementa o contador de trocas
        }
    }
}

void SelectionSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    int min, i, j;
    string auxiliar;

    for (i = 0; i < VetorParaString.size(); i++)
    {
        min = i;

        for (j = i + 1; j < VetorParaString.size(); j++)
        {
            if (VetorParaString[j] < VetorParaString[min])
            {
                (*comparar)++;
                min = j;
            }
            else
            {
                (*comparar)++;
            }
        }

        // Troca as posições entre as strings usando std::swap
        if (min != i)
        {
            std::swap(VetorParaString[i], VetorParaString[min]);
            (*swap)++;
        }
    }
}

void QuickSort_String(vector<string> &VetorParaString, int esq, int dir, unsigned long long *comparar, unsigned long long *swap)
{
    string temp;
    int i = esq, j = dir;
    string pivo = VetorParaString[(esq + dir) / 2]; // escolha do pivô

    // particionamento do vetor
    while (i <= j)
    {
        while (VetorParaString[i] < pivo)
            i++;
        while (VetorParaString[j] > pivo)
            j--;

        (*comparar)++;
        if (i <= j)
        {
            temp = VetorParaString[i];
            VetorParaString[i] = VetorParaString[j];
            VetorParaString[j] = temp;
            i++;
            j--;

            (*swap)++;
        }
    }

    // chamada recursiva para as sub-listas
    (*comparar)++;
    if (esq < j)
        QuickSort_String(VetorParaString, esq, j, comparar, swap);
    (*comparar)++;
    if (i < dir)
        QuickSort_String(VetorParaString, i, dir, comparar, swap);
}

void Merge_String(vector<string> &VetorParaString, int inicio, int meio, int final, unsigned long long *comparar, unsigned long long *swap)
{
    int i, j, k;
    int n1 = meio - inicio + 1;
    int n2 = final - meio;

    string *L = new string[n1];
    string *R = new string[n2];

    for (i = 0; i < n1; i++)
    {
        L[i] = VetorParaString[inicio + i];
    }
    for (j = 0; j < n2; j++)
    {
        R[j] = VetorParaString[meio + 1 + j];
    }

    i = 0;
    j = 0;
    k = inicio;

    while (i < n1 && j < n2)
    {
        (*comparar)++;
        if (L[i] <= R[j])
        {
            VetorParaString[k] = L[i];
            i++;
        }
        else
        {
            VetorParaString[k] = R[j];
            j++;
        }
        k++;
        (*swap)++;
    }

    while (i < n1)
    {
        VetorParaString[k] = L[i];
        i++;
        k++;
        (*swap)++;
    }

    while (j < n2)
    {
        VetorParaString[k] = R[j];
        j++;
        k++;
        (*swap)++;
    }
}

void MergeSort_for_String(vector<string> &VetorParaString, int inicio, int final, unsigned long long *comparar, unsigned long long *swap)
{
    if (inicio < final)
    {
        int meio = inicio + (final - inicio) / 2;

        MergeSort_for_String(VetorParaString, inicio, meio, comparar, swap);
        MergeSort_for_String(VetorParaString, meio + 1, final, comparar, swap);

        Merge_String(VetorParaString, inicio, meio, final, comparar, swap);
    }
}

void ShellSort_for_String(vector<string> &VetorParaString, unsigned long long *comparar, unsigned long long *swap)
{
    int h, i, j;
    string x; 

    for (h = 1; h < VetorParaString.size(); h = 3 * h + 1)
        ;
    while (h > 1)
    {
        h = h / 3;
        (*comparar)++;
        for (i = h; i < VetorParaString.size(); i++)
        {
            x = VetorParaString[i];
            j = i;
            while (j >= h && VetorParaString[j - h] > x)
            {
                (*comparar)++;
                VetorParaString[j] = VetorParaString[j - h];
                j = j - h;
                (*swap)++;
            }
            VetorParaString[j] = x;
            (*comparar)++;
        }
    }
}

// --------------------- FUNÇÕES DE MANIPULAÇÃO --------------------- //

void ImprimirAString(vector<string> &VetorParaString) // Imprime o vetor
{
    for (int i = 0; i < VetorParaString.size(); i++)
    {
        cout << VetorParaString[i] << endl;
    }
}

void OrdenarArquivo(vector<int> &NumeroParaVetor, vector<string> &VetorParaString, int metodo, int instancia) // Ordena o arquivo
{
    unsigned long long comparar = 0, swap = 0; // Contadores de comparações e trocas
    clock_t inicio, final;                       // Contadores de TempoA
    long double TempoA;                         // TempoA de execução

    LerArquivo(instancia, NumeroParaVetor, VetorParaString);

    switch (metodo)
    {
    case 1:
        inicio = clock();
        BubbleSort(NumeroParaVetor, &comparar, &swap);
        final = clock();
        break;
    case 2:
        inicio = clock();
        InsertionSort(NumeroParaVetor, &comparar, &swap);
        final = clock();
        break;
    case 3:
        inicio = clock();
        SelectionSort(NumeroParaVetor, &comparar, &swap);
        final = clock();
        break;
    case 4:
        inicio = clock();
        QuickSort(NumeroParaVetor, 0, NumeroParaVetor.size() - 1, &comparar, &swap);
        final = clock();
        break;
    case 5:
        inicio = clock();
        MergeSort(NumeroParaVetor, 0, NumeroParaVetor.size() - 1, &comparar, &swap);
        final = clock();
        break;
    case 6:
        inicio = clock();
        ShellSort(NumeroParaVetor, &comparar, &swap);
        final = clock();
        break;
    default:
        cout << "Saindo..." << endl;
        return;
    }

    TempoA = (double)(final - inicio) / CLOCKS_PER_SEC;

    for (int i = 0; i < NumeroParaVetor.size(); i++)
    {
        cout << NumeroParaVetor[i] << " ";
    }

    NumeroParaVetor.clear();

    cout << "\nNumero de trocas: " << swap << endl;
    cout << "Numero de comparacoes: " << comparar << endl;
    cout << "Tempo usado: " << TempoA << endl;
}

long double OrdenarString(vector<string> &VetorParaString, int metodo, unsigned long long *comparar, unsigned long long *swap)
{ // Ordena o arquivo
    clock_t inicio, final;
    long double TempoA;

    switch (metodo)
    {
    case 1:
        inicio = clock();
        BubbleSort_for_String(VetorParaString, comparar, swap);
        final = clock();
        break;
    case 2:
        inicio = clock();
        InsertionSort_for_String(VetorParaString, comparar, swap);
        final = clock();
        break;
    case 3:
        inicio = clock();
        SelectionSort_for_String(VetorParaString, comparar, swap);
        final = clock();
        break;
    case 4:
        inicio = clock();
        QuickSort_String(VetorParaString, 0, VetorParaString.size() - 1, comparar, swap);
        final = clock();
        break;
    case 5:
        inicio = clock();
        MergeSort_for_String(VetorParaString, 0, VetorParaString.size() - 1, comparar, swap);
        final = clock();
        break;
    case 6:
        inicio = clock();
        ShellSort_for_String(VetorParaString, comparar, swap);
        final = clock();
        break;
    default:
        throw invalid_argument("Método invalido!!!.");
    }

    TempoA = (double)(final - inicio) / CLOCKS_PER_SEC;
    return TempoA;
}

void OrdenarArquivoDaString(vector<string> &VetorParaString, vector<int> &NumeroParaVetor, int metodo, int instancia)
{
    unsigned long long comparar = 0, swap = 0;
    long double TempoA;

    LerArquivo(instancia, NumeroParaVetor, VetorParaString);

    TempoA = OrdenarString(VetorParaString, metodo, &comparar, &swap);

    ImprimirAString(VetorParaString);

    cout << "Numero de trocas: " << swap << endl;
    cout << "comparar: " << comparar << endl;
    cout << "Tempo usado: " << TempoA << endl;
}

void BackMenuPrincipal()
{
    int opcao;
    cout << "Deseja voltar ao menu principal? (1 - Sim / 2 - Nao)" << endl;
    cin >> opcao;
    if (opcao == 1)
    {
        system("cls");
        MenuPrincipal();
    }
    else
    {
        cout << "Saindo..." << endl;
        exit(0);
    }
}

/*
void eficacia(int metodo, int instancia)
{
    vector<int> NumeroParaVetor;
    vector<string> VetorParaString;
    unsigned long long comparar = 0, swap = 0;
    long double TempoA;

    LerArquivo(instancia, NumeroParaVetor, VetorParaString);

    TempoA = OrdenarString(VetorParaString, metodo, &comparar, &swap);

    cout << "Numero de trocas: " << swap << endl;
    cout << "comparar: " << comparar << endl;
    cout << "Tempo usado: " << TempoA << endl;
}
*/

